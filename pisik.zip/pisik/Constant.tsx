export interface Num {
    value: number
    indi: number
}


export interface Passed {
        value: number
        pstate: boolean
        dura: number
}

export interface Width {
    wnum: number
}
